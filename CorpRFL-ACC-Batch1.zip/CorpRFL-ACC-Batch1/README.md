# CorpRFL-ACC Batch 1
Core engine: multi-company + database setup.